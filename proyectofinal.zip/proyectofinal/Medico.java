package proyectofinal;

import java.util.Arrays;

public class Medico extends Persona {
    private String especialidad;
    private String[] horariosDisponibles;

    public Medico(String cedula, String nombre, String telefono, String correo, String especialidad) {
        super(cedula, nombre, telefono, correo);
        this.especialidad = especialidad;
        this.horariosDisponibles = new String[10];
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void agregarHorario(String horario, int indice) {
        if (indice >= 0 && indice < horariosDisponibles.length) {
            horariosDisponibles[indice] = horario;
        }
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Médico Cédula: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Teléfono: " + getTelefono());
        System.out.println("Correo: " + getCorreo());
        System.out.println("Especialidad: " + especialidad);
        System.out.println("Horarios Disponibles: " + Arrays.toString(horariosDisponibles));
    }
}


