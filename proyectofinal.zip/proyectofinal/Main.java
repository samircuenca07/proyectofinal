package proyectofinal;

import java.util.ArrayList;
import javax.swing.*;
import java.util.regex.Pattern;

public class Main {
    private static ArrayList<Paciente> pacientes = new ArrayList<>();
    private static ArrayList<Medico> medicos = new ArrayList<>();
    private static ArrayList<Cita> citas = new ArrayList<>();

    public static void main(String[] args) {
        String[] opciones = {
                "Registrar Paciente",
                "Registrar Médico",
                "Programar Cita",
                "Ver Pacientes",
                "Ver Médicos",
                "Ver Citas",
                "Salir"
        };

        int opcion;
        do {
            opcion = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción",
                    "Gestión de Citas Médicas",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );

            switch (opcion) {
                case 0 -> registrarPaciente();
                case 1 -> registrarMedico();
                case 2 -> programarCita();
                case 3 -> verPacientes();
                case 4 -> verMedicos();
                case 5 -> verCitas();
                case 6 -> JOptionPane.showMessageDialog(null, "Saliendo del sistema...");
                default -> JOptionPane.showMessageDialog(null, "Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 6);
    }

    private static void registrarPaciente() {
        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del paciente:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del paciente:");
        String telefono = JOptionPane.showInputDialog("Ingrese el teléfono del paciente:");
        String correo = JOptionPane.showInputDialog("Ingrese el correo del paciente:");

        Paciente paciente = new Paciente(cedula, nombre, telefono, correo);
        pacientes.add(paciente);
        JOptionPane.showMessageDialog(null, "Paciente registrado exitosamente.");
    }

    private static void registrarMedico() {
        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del médico:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del médico:");
        String telefono = JOptionPane.showInputDialog("Ingrese el teléfono del médico:");
        String correo = JOptionPane.showInputDialog("Ingrese el correo del médico:");
        String especialidad = JOptionPane.showInputDialog("Ingrese la especialidad del médico:");

        Medico medico = new Medico(cedula, nombre, telefono, correo, especialidad);
        medicos.add(medico);
        JOptionPane.showMessageDialog(null, "Médico registrado exitosamente.");
    }

    private static void programarCita() {
        String fecha = validarEntrada("Ingrese la fecha (formato dd/mm/aa):", "^\\d{2}/\\d{2}/\\d{2}$");
        if (fecha == null) return;

        String hora = validarEntrada("Ingrese la hora (formato hh:mm):", "^\\d{2}:\\d{2}$");
        if (hora == null) return;

        StringBuilder listaPacientes = new StringBuilder("Seleccione un paciente por cédula:\n");
        for (Paciente paciente : pacientes) {
            listaPacientes.append(paciente.getId()).append(": ").append(paciente.getNombre()).append("\n");
        }
        String pacienteCedula = JOptionPane.showInputDialog(listaPacientes.toString());
        Paciente paciente = pacientes.stream()
                .filter(p -> p.getId().equals(pacienteCedula))
                .findFirst()
                .orElse(null);

        if (paciente == null) {
            JOptionPane.showMessageDialog(null, "Paciente no encontrado.");
            return;
        }

        StringBuilder listaMedicos = new StringBuilder("Seleccione un médico por cédula:\n");
        for (Medico medico : medicos) {
            listaMedicos.append(medico.getId()).append(": ").append(medico.getNombre()).append("\n");
        }
        String medicoCedula = JOptionPane.showInputDialog(listaMedicos.toString());
        Medico medico = medicos.stream()
                .filter(m -> m.getId().equals(medicoCedula))
                .findFirst()
                .orElse(null);

        if (medico == null) {
            JOptionPane.showMessageDialog(null, "Médico no encontrado.");
            return;
        }

        String motivo = JOptionPane.showInputDialog("Ingrese el motivo de la cita:");

        Cita cita = new Cita(fecha + " " + hora, paciente, medico, motivo);
        citas.add(cita);
        paciente.agregarCita(fecha + " " + hora);
        JOptionPane.showMessageDialog(null, "Cita programada exitosamente.");
    }

    private static String validarEntrada(String mensaje, String regex) {
        String entrada;
        do {
            entrada = JOptionPane.showInputDialog(mensaje);
            if (entrada == null) return null;
            if (!Pattern.matches(regex, entrada)) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Intente nuevamente.");
                entrada = null;
            }
        } while (entrada == null);
        return entrada;
    }

    private static void verPacientes() {
        if (pacientes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay pacientes registrados.");
        } else {
            StringBuilder lista = new StringBuilder("--- Lista de Pacientes ---\n");
            for (Paciente paciente : pacientes) {
                lista.append(paciente.getId()).append(": ").append(paciente.getNombre()).append("\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }

    private static void verMedicos() {
        if (medicos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay médicos registrados.");
        } else {
            StringBuilder lista = new StringBuilder("--- Lista de Médicos ---\n");
            for (Medico medico : medicos) {
                lista.append(medico.getId()).append(": ").append(medico.getNombre()).append("\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }

    private static void verCitas() {
        if (citas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay citas registradas.");
        } else {
            StringBuilder lista = new StringBuilder("--- Lista de Citas ---\n");
            for (Cita cita : citas) {
                lista.append(cita).append("\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }
}
