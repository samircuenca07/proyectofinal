package proyectofinal;

public class Cita {
    private String fechaHora;
    private Paciente paciente;
    private Medico medico;
    private String motivo;

    public Cita(String fechaHora, Paciente paciente, Medico medico, String motivo) {
        this.fechaHora = fechaHora;
        this.paciente = paciente;
        this.medico = medico;
        this.motivo = motivo;
    }

    @Override
    public String toString() {
        return "Cita Fecha y Hora: " + fechaHora +
                ", Paciente: " + paciente.getNombre() +
                ", Médico: " + medico.getNombre() +
                ", Motivo: " + motivo;
    }
}

