package proyectofinal;

import java.util.ArrayList;

public class Paciente extends Persona {
    private ArrayList<String> historialCitas;

    public Paciente(String cedula, String nombre, String telefono, String correo) {
        super(cedula, nombre, telefono, correo);
        this.historialCitas = new ArrayList<>();
    }

    public void agregarCita(String cita) {
        historialCitas.add(cita);
    }

    public ArrayList<String> getHistorialCitas() {
        return historialCitas;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Paciente Cédula: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Teléfono: " + getTelefono());
        System.out.println("Correo: " + getCorreo());
        System.out.println("Historial de citas: " + historialCitas);
    }
}


